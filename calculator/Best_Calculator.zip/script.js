document.getElementById('singlebox1').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow1');
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');   
    }, 300);
});
document.getElementById('singlebox2').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow2',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');  
    }, 300);
});
document.getElementById('singlebox3').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow3',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');  
    }, 300);
});
document.getElementById('singlebox4').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow4',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox5').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow5',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox6').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow6',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox7').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow7',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox8').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow8',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox9').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow9',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox10').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow10',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox11').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow11',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox12').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow12',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox13').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow13',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox14').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow14',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox15').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow15',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox16').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow16',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox17').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow17',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox18').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow18',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox19').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow19',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
document.getElementById('singlebox20').addEventListener('click', function() {
    var buttonshadow1 = document.getElementById('btnshadow20',);
    buttonshadow1.classList.add('shadow1');
    buttonshadow1.classList.remove('shadow2');
    setTimeout(() => {
        buttonshadow1.classList.add('shadow2');     
    }, 300);
});
